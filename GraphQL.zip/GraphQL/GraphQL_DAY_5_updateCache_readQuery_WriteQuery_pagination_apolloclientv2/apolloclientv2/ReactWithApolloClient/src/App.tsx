import React from 'react';
import logo from './logo.svg';
import './App.css';
import BasicComponent from './basic.component';
import Product from './product.component';
import ProductModel from './product.model';
import ListOfProducts from './listofproducts.component';
import gql from 'graphql-tag';
import { Query } from 'react-apollo';

const GET_ALL_PRODUCTS = gql`
  query{
    products{
      id,
      name,
      rating,
      likes,
      quantity,
      price,
      imageUrl
    }
  }
`
export const App = () => {
  return(
    <div>
         <Query query={GET_ALL_PRODUCTS}>
            {
              (result:any)=>{
                const {data,loading,error} = result;
                return <ListOfProducts allproducts={data} />
              }
            }
         </Query>
    </div>
  )
}
export default App;














  //render() {
    // return <div>
    //   <BasicComponent msg="Hi"/>
    //   <BasicComponent msg="Hola" />
    //   <BasicComponent msg="Namaste" />
    //   <BasicComponent  />
    // </div>   
 // }

