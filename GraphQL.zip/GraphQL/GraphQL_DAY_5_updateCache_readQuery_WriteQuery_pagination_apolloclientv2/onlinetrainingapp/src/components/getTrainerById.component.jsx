import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { GET_TRAINER_BY_ID } from "../graphql/queries";

export default function GetTrainerById() {
  const [trainerId, setTrainerId] = useState("");
  const { error, loading, data } = useQuery(GET_TRAINER_BY_ID, {
    variables: { trainerId: trainerId },
  });

  return (
    <div>
      <form>
        <label htmlFor="txtTrainerId">Enter Trainer Id : </label>
        <input
          type="text"
          id="txtTrainerId"
          onChange={(e) => setTrainerId(e.target.value)}
        />
        {loading ? <h4>Loading...</h4> : <h2>{data.trainer?.name}</h2>}{" "}
      </form>
    </div>
  );
}
