import { gql, useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { GET_ALL_TRAINERS } from "../graphql/queries";
// 1. write a graphql query
// 2. fire/execute the query
// 3. async - useEffect
// 4. once data received display in UI

export default function ListOfTrainers() {
  const { error, loading, data } = useQuery(GET_ALL_TRAINERS);
  const [trainers, setTrainers] = useState([]);

  useEffect(() => {
    if (!loading) {
      setTrainers(data.trainers);
    }
  }, [data]);

  return (
    <div>
      <h2>Meet Our Trainers</h2>
      <ul className="list-group">
        {loading
          ? "Loading.."
          : trainers.map((trainer) => (
              <li key={trainer.id} className="list-group-item">
                <Link to={`/trainer/${trainer.id}`}>{trainer.name}</Link>
              </li>
            ))}
      </ul>
    </div>
  );
}
