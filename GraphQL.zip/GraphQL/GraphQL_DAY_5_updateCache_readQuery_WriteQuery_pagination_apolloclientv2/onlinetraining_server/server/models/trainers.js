const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const trainerSchema = new Schema({
  id: Number,
  name: String,
  age: Number,
  isMCT: Boolean,
  avatarUrl: String,
  description: String,
});

module.exports = mongoose.model("Trainers", trainerSchema);
