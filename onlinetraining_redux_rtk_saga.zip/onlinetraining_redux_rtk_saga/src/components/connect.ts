import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import App from "../App";
import * as AllActions from "../redux/actions/actions";

function mapStateToProps(store: any) {
  return {
    allCourses: store.courses,
    allTrainers: store.trainers,
  };
}
// store.dispatch({type:"INCREMENT_LIKES"})
function mapDispatchToProps(dispatcher: any) {
  return bindActionCreators(AllActions, dispatcher);
}

const MainApp = connect(mapStateToProps, mapDispatchToProps)(App);

export default MainApp;
