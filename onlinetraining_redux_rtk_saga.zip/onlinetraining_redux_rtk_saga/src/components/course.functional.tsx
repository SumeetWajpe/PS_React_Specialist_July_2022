import { ICourseProps, ICoursePropsFC } from "../props/ICourseProps";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { IncrementLikes } from "../redux/actions/actions";
import {
  deleteACourse,
  incrementLikes,
} from "../redux/reducers/courses.reducer";
// export const CourseFC = (props: ICourseProps) => {
//   return (
//     <>
//       <p>Course</p>
//     </>
//   );
// };

// export const CourseFC = ({ coursedetails }: ICourseProps) => {
//   return (
//     <>
//       <p>{coursedetails.title}</p>
//     </>
//   );
// };

let CourseFC: React.FC<ICoursePropsFC> = ({ coursedetails }) => {
  const dispatch = useDispatch();
  let ratings = [];
  for (let index = 0; index < coursedetails.rating; index++) {
    ratings.push(
      <i
        className="fa-solid fa-star"
        key={index}
        style={{ color: "orange" }}
      ></i>,
    );
  }
  return (
    <>
      <div className="col-md-3">
        <div className="card m-2">
          <img
            src={coursedetails.imageUrl}
            height="150px"
            className="card-img-top"
            alt={coursedetails.title}
          />
          <div className="card-body">
            <h5 className="card-title m-0">{coursedetails.title}</h5>
            <div className="m-0">{ratings}</div>

            <p className="card-text m-0">{coursedetails.trainer}</p>
            <p className="card-text">
              <strong>₹. {coursedetails.price}</strong>{" "}
            </p>

            <button
              className="btn btn-primary"
              onClick={() => dispatch(incrementLikes(coursedetails.id))}
            >
              {coursedetails.likes} <i className="fa-solid fa-thumbs-up"></i>
            </button>
            <button
              className="btn btn-danger mx-2"
              onClick={() => dispatch(deleteACourse(coursedetails.id))}
            >
              <i className="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

CourseFC = React.memo(CourseFC);
export { CourseFC };
