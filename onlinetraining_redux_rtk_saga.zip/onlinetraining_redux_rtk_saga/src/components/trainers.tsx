import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";

import { AppDispatch, RootState } from "../redux/store/store";
import { sagaActions } from "../saga/sagaActions";

export const Trainers: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const trainers = useSelector((store: RootState) => store.trainers.trainers);
  useEffect(() => {
    // dispatch({ type: sagaActions.FETCH_TRAINERS_DATA_SAGA });
  }, []);

  return (
    <>
      <h2>Meet Our Trainers</h2>

      <button
        className="btn btn-primary"
        onClick={() => dispatch({ type: sagaActions.FETCH_TRAINERS_DATA_SAGA })}
      >
        Get Trainers
      </button>

      <ul className="list-group">
        {trainers.map(
          (
            user: any, // use user model
          ) => (
            <li key={user.id} className="list-group-item">
              {/* <Link to={"/trainers/" + user.login}>{user.login}</Link> */}
              {user.login}
            </li>
          ),
        )}
      </ul>
    </>
  );
};
