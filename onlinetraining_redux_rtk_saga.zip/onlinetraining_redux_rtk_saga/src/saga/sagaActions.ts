export const sagaActions = {
  FETCH_TRAINERS_DATA_SAGA: "FETCH_TRAINERS_DATA_SAGA",
};
