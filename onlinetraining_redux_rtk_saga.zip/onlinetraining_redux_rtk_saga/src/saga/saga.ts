import axios from "axios";
import { all, call, put, retry, takeLatest } from "redux-saga/effects";
import { TrainerModel } from "../model/trainer.model";
import { setTrainers } from "../redux/reducers/trainers.reducer";
import { sagaActions } from "./sagaActions";

export interface Response {
  config?: any;
  data?: any;
  headers?: any;
  request?: any;
  status?: number;
  statusText?: string;
}

const getTrainers = () =>
  axios.get<TrainerModel[]>("https://api.github.com/users");

export function* fetchTrainersFromAPI() {
  try {
    const response: Response = yield call(getTrainers); // make async req
    yield put(setTrainers(response.data)); // dispatch
  } catch (error) {
    // dispatch and ERROR_ACTION
  }
}

export function* fetchTrainersFROMAPIwithRetry() {
  try {
    let duration = 1000;
    let response: Response = yield retry(3, duration * 10, getTrainers);
    yield put(setTrainers(response.data)); // dispatch
  } catch (error) {}
}

export function* fetchTrainers() {
  // yield takeLatest(sagaActions.FETCH_TRAINERS_DATA_SAGA, fetchTrainersFromAPI);
  yield takeLatest(
    sagaActions.FETCH_TRAINERS_DATA_SAGA,
    fetchTrainersFROMAPIwithRetry,
  );
}

export default function* rootSaga() {
  yield all([fetchTrainers()]);
}
