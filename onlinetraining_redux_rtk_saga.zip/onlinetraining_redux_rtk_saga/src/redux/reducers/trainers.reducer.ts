import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TrainerModel } from "../../model/trainer.model";
import { createAction } from "@reduxjs/toolkit";

export const addTodoAsync = createAction("todo/addTodoAsync");

export interface TrainersState {
  trainers: TrainerModel[];
}

const initialState: TrainersState = {
  trainers: [],
};

export const trainersSlice = createSlice({
  name: "trainers",
  initialState,
  reducers: {
    setTrainers: (state, { payload }: PayloadAction<TrainerModel[]>) => {
      state.trainers.push(...payload);
    },
  },
});
export const { setTrainers } = trainersSlice.actions;

export default trainersSlice.reducer;
