import { AnyAction } from "redux";
import { ThunkAction } from "redux-thunk";
import { CourseModel } from "../../model/course.model";
import { TrainerModel } from "../../model/trainer.model";
import store from "../store/store";

const INCREMENT_LIKES = "INCREMENT_LIKES";

// Action Creators
export function IncrementLikes(payload: number) {
  return { type: INCREMENT_LIKES, payload }; // Action
}

export function FetchAllTrainers(payload: TrainerModel[]) {
  return { type: "FETCH_ALL_TRAINERS", payload };
}

export function FetchAllTrainersAsync() {
  return (dispatch: any) => {
    fetch("https://api.github.com/users")
      .then(res => {
        console.log("first");
        return res.json();
      })
      .then(trainers => dispatch(FetchAllTrainers(trainers)));
  };
}

export function DeleteACourse(payload: number) {
  return { type: "DELETE_A_COURSE", payload };
}

export function AddACourse() {
  return { type: "ADD_A_COURSE" };
}

export function AddATrainer() {
  return { type: "ADD_A_TRAINER" };
}

export function DeleteATrainer() {
  return { type: "DELETE_A_TRAINER" };
}
