import { CourseModel } from "../../model/course.model";
import { TrainerModel } from "../../model/trainer.model";

export interface IncrementLikesAction {
  type: string;
  payload: number;
}
export interface DeleteACourseAction {
  type: string;
  payload: number;
}
export interface AddACourseAction {
  type: string;
  payload: CourseModel;
}
export interface FetchAllTrainersAction {
  type: string;
  payload: TrainerModel[];
}

