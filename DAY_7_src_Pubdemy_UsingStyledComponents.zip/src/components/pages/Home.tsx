import { PageLayout } from "../common/PageLayout";

export const Home: React.FC = () => {
  return (
    <>
      <PageLayout>
        <h1>Home</h1>
      </PageLayout>
    </>
  );
};
