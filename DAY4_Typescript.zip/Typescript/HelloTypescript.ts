// var msg = "Hello Typescript !"; // Type Inference
// //msg = 100;
// console.log(typeof msg);

// var msg:string = "Hello Typescript"; // Type annotation
// console.log(msg);

// var age:number;
// age = 16;

// var ans:boolean =true;

// var x;
// x = 100;
// x = [100,200];
// x = {name:"XYZ"};

// // Arrays
// let cars:string[] = ["BMW","AUDI","Porche"];
// let moreCars:Array<string> = new Array<string>("TATA","MAHINDRA");

// Functions

function Square(x) {
    return x * x;
}
// function Addition(x:number,y:number):number|string {
//     if(x == 0){
//         return "X cannot be zero !";
//     }
//     return x + y;
// }

// // Addition(); // Error !
// let result:number|string = Addition(20,30);

// Optional parameters

// function Addition(x?:number,y?:number) {
//     return x + y;
// }


// function PrintBook(author:string,title?:string,publisher?:string):void {
//     console.log(author,title,publisher);
// }

// PrintBook("Dr.APJ Abdul Kalam","Wings Of Fire","Jaico");
// PrintBook("Dummy")

// Default parameters
// function PrintBook(author:string="Unknown",title:string="Unknown",publisher:string="Unknown"):void {
//     console.log(author,title,publisher);
// }

// PrintBook();

// Rest Parameters
// function PrintBook(author:string,...titles:string[]) {
//     console.log(author,titles)
// }

// PrintBook("Dr.APJ Abdul Kalam","Wings Of Fire","India 2020");

// Enum

enum Designation{
    Developer=100,
    Tester,
    Architect,
    TeamLead
}

var d = Designation.Architect;
console.log(d);//prints the numeric rep
console.log(Designation[d]);

// Interfaces
interface IPlayer{
    name:string;
    country:string;
    sport:string;
    getDetails?():void;// optional
}
var player:IPlayer = {name:"Djokovic",country:"Serbia",sport:"Tennis"};



class Car{
    private id = 1;
    name:string ;
    speed:number;

    constructor(name:string="BMW",speed:number=200){
        this.name = name;
        this.speed = speed;
    }
    accelerate():string{
        return `${this.id}.The car ${this.name} is running at ${this.speed} kmph !`
    }
}

// var carObj = new Car();
// console.log(carObj.accelerate());

class JamesBondCar extends Car{
    useNitro:boolean;
    constructor(name:string,speed:number,useNitro:boolean=false){
        super(name,speed);
        this.useNitro = useNitro;
    }
    accelerate(): string {
        return `${super.accelerate()} , Can use nitro power : ${this.useNitro}`
    }
}

var jbc = new JamesBondCar("Aston Martin",300,true);
console.log(jbc.accelerate());

interface IPerson{
    age:number;
}

class Player implements IPlayer,IPerson{
     name:string;
     age:number;
    country:string;
    sport:string;
    getDetails():void{
        console.log()
    }
}

// Enhanced Class Syntax
class EnhancedCar{
    constructor(private id:number,public name:string,public speed:number){

    }
}

var enhancedCar = new EnhancedCar(1,"Audi",300);


// Generics
// class Point<T>{
//     x:T;
//     y:T;

//     constructor(x:T,y:T){
//         this.x = x;
//         this.y = y;
//     }
// }

//var point:Point<number> = new Point<number>("10","20");

// var anotherPoint<string> = new Point<string>();

function Swap<T>(x:T,y:T) {
    let t:T;
    t =x;
    x= y;
    y=t;

}


Swap<number>(10,20);
Swap<string>("Hello","World !");
