import logo from "./logo.svg";
import "./App.css";
import React from "react";
import Product from "./components/product.component";
import FunctionalCounter from "./components/functional.component";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [
        { id: 1, name: "MacBookPro", price: 250000, likes: 200 },
        { id: 2, name: "Alienware", price: 350000, likes: 300 },
        { id: 3, name: "Dell Inspiron", price: 50000, likes: 500 },
      ],
    };
  }

  DeleteAProduct(theProductId) {
    console.log("Deleting Product", theProductId);
    // filter
    let newProductList = this.state.products.filter(p => p.id !== theProductId);
    this.setState({ products: newProductList });
  }
  render() {
    let productsToBeCreated = this.state.products.map((product, index) => (
      <Product
        productdetails={product}
        key={product.id}
        DeleteAProduct={theProductId => this.DeleteAProduct(theProductId)}
      />
    ));
    // return <div>{productsToBeCreated}</div>;

    return <FunctionalCounter />;
  }
}

export default App;
