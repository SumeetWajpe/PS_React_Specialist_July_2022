// 15.x 16.x  -> 1. No state 1. No Lifecycle methods 3. No render 16.8 -> Hooks() -> useState() / useMemo() / useReducer()


// Light weighted component
// Presentational component

import React from 'react'
import { useState } from 'react'

export default function FunctionalCounter() {
  let [counter,setCounter] =  useState({count:100,age:18})
  return (
    <div>
        <h3>Count : {counter.count}</h3>
        <h3>Age : {counter.age}</h3>
        <button onClick={()=>setCounter({...counter,count:counter.count+1})}>++</button>
    </div>
  )
}
