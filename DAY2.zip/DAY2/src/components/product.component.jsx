import React, { Component } from 'react'

export default class Product extends Component {
    constructor(props){
        super(props);
        this.state = {currLikes:100,dislikes:200,};
        this.IncrementLikes = this.IncrementLikes.bind(this);
    
    }

    IncrementLikes(){
        console.log("Within  Increment Likes !");
        this.setState({currLikes:this.state.currLikes+1});
    }
    

  render() {
    return (
      <div>
        <h2>{this.props.productdetails.name}</h2>
        {/* <button>{this.props.productdetails.likes}</button> */}
        <button onClick={this.IncrementLikes}>{this.state.currLikes}</button>
        <button onClick={()=>this.props.DeleteAProduct(this.props.productdetails.id)}>Delete</button>
        <hr />
      </div>
    )
  }
}
