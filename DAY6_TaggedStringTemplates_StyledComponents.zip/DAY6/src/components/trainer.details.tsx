import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

export const TrainerDetail: React.FC = () => {
  let { login } = useParams();
  let [trainer, setTrainer] = useState<any>({}); // use user model
  useEffect(() => {
    fetch("https://api.github.com/users/" + login)
      .then(res => res.json())
      .then(trainer => setTrainer(trainer));
  }, []);
  return (
    <>
      <h2>Trainer Details for {login}</h2>
      <div>
        <h3>Name : {trainer.login}</h3>
        <img src={trainer.avatar_url} alt={trainer.login} height="100px" />
      </div>
    </>
  );
};
