import { ICourseProps, ICoursePropsFC } from "../props/ICourseProps";
import React, { useState } from "react";
// export const CourseFC = (props: ICourseProps) => {
//   return (
//     <>
//       <p>Course</p>
//     </>
//   );
// };

// export const CourseFC = ({ coursedetails }: ICourseProps) => {
//   return (
//     <>
//       <p>{coursedetails.title}</p>
//     </>
//   );
// };

export const CourseFC: React.FC<ICoursePropsFC> = ({
  coursedetails,
  DeleteACourse,
}) => {
  const [currLikes, setCurrLikes] = useState(coursedetails.likes);
  let ratings = [];
  for (let index = 0; index < coursedetails.rating; index++) {
    ratings.push(
      <i
        className="fa-solid fa-star"
        key={index}
        style={{ color: "orange" }}
      ></i>,
    );
  }
  return (
    <>
      <div className="col-md-3">
        <div className="card m-2">
          <img
            src={coursedetails.imageUrl}
            height="150px"
            className="card-img-top"
            alt={coursedetails.title}
          />
          <div className="card-body">
            <div className="row">
              <div className="col">
                <h5 className="card-title">{coursedetails.title}</h5>
              </div>
              <div className="col">{ratings}</div>
            </div>

            <p className="card-text">{coursedetails.trainer}</p>
            <p className="card-text">
              <strong>₹. {coursedetails.price}</strong>{" "}
            </p>

            <button
              className="btn btn-primary"
              onClick={() => setCurrLikes(currLikes + 1)}
            >
              {currLikes} <i className="fa-solid fa-thumbs-up"></i>
            </button>
            <button
              className="btn btn-danger mx-2"
              onClick={() => DeleteACourse(coursedetails.id)}
            >
              <i className="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

// export const CourseList: React.FC = () => {
//   let [name, setName] = useState("");
//   let [courseList, setCourseList] = useState<string[]>([]);

//   const onClickHandler = () => {
//     setCourseList([...courseList, name]);
//   };

//   return (
//     <>
//       <h3>CourseList</h3>
//       <label htmlFor="txtCourseName">Coursename :</label>{" "}
//       <input
//         type="text"
//         id="txtCourseName"
//         onChange={e => setName(e.target.value)}
//       />{" "}
//       <button onClick={onClickHandler}>Add</button>
//       <ul>
//         {courseList.map(c => (
//           <li key={c}>{c}</li>
//         ))}
//       </ul>
//     </>
//   );
// };
