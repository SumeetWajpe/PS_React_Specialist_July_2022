import React, { Component } from "react";
import { ICourseProps } from "../props/ICourseProps";
import { ICourseState } from "../state/ICourseState";

export default class Course extends Component<ICourseProps, ICourseState> {
  state: Readonly<ICourseState> = {
    currLikes: this.props.coursedetails.likes,
  };
  IncrementLikes(): void {
    this.setState({ currLikes: this.state.currLikes + 1 });
  }
  render() {
    let ratings = [];
    for (let index = 0; index < this.props.coursedetails.rating; index++) {
      ratings.push(
        <i
          className="fa-solid fa-star"
          key={index}
          style={{ color: "orange" }}
        ></i>,
      );
    }
    return (
      <div className="col-md-3">
        <div className="card m-2">
          <img
            src={this.props.coursedetails.imageUrl}
            height="150px"
            className="card-img-top"
            alt={this.props.coursedetails.title}
          />
          <div className="card-body">
            <div className="row">
              <div className="col">
                <h5 className="card-title">{this.props.coursedetails.title}</h5>
              </div>
              <div className="col">{ratings}</div>
            </div>

            <p className="card-text">{this.props.coursedetails.trainer}</p>
            <p className="card-text">
              <strong>₹. {this.props.coursedetails.price}</strong>{" "}
            </p>

            <button
              className="btn btn-primary"
              onClick={() => this.IncrementLikes()}
            >
              {this.state.currLikes} <i className="fa-solid fa-thumbs-up"></i>
            </button>
            <button
              className="btn btn-danger mx-2"
              onClick={() =>
                this.props.DeleteACourse(this.props.coursedetails.id)
              }
            >
              <i className="fa-solid fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}
