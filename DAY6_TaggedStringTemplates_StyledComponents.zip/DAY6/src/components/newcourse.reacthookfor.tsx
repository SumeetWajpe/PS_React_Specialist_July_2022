import React from "react";
import { useForm } from "react-hook-form";

type Inputs = {
  CourseId: number;
  CourseTitle: string;
  CoursePrice: number;
  CourseLikes: number;
  CourseRating: number;
  CourseTrainer: string;
  CourseImageUrl: string;
};

export const NewCourse: React.FC = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<Inputs>({ mode: "onChange" });
  return (
    <div className="col-md-4">
      <form onSubmit={handleSubmit(data => console.log(data))}>
        <h2>New Course</h2>
        <label htmlFor="txtCourseId">Id :</label>
        <input
          type="number"
          id="txtCourseId"
          className="form-control"
          {...register("CourseId", { required: "Course Id is required !" })}
        />
        {errors.CourseId && (
          <p style={{ color: "red" }}>{errors.CourseId.message}</p>
        )}
        <label htmlFor="txtCourseTitle">Title :</label>{" "}
        <input
          type="text"
          id="txtCourseTitle"
          className="form-control"
          {...register("CourseTitle", {
            required: "Course Title is required !",
            maxLength: {
              value: 20,
              message: "You exceeded max length of 20 !",
            },
          })}
        />
        {errors.CourseTitle && (
          <p style={{ color: "red" }}>{errors.CourseTitle.message}</p>
        )}
        <label htmlFor="txtCoursePrice">Price :</label>{" "}
        <input
          type="number"
          id="txtCoursePrice"
          className="form-control"
          {...register("CoursePrice")}
        />{" "}
        <label htmlFor="txtCourseLikes">Likes :</label>{" "}
        <input
          type="number"
          id="txtCourseLikes"
          className="form-control"
          {...register("CourseLikes")}
        />{" "}
        <label htmlFor="txtCourseRating">Rating :</label>
        <input
          type="number"
          id="txtCourseRating"
          className="form-control"
          {...register("CourseRating")}
        />{" "}
        <label htmlFor="txtCourseTrainer">Trainer :</label>{" "}
        <input
          type="text"
          id="txtCourseTrainer"
          className="form-control"
          {...register("CourseTrainer")}
        />{" "}
        <label htmlFor="txtCourseImageUrl">Image URL :</label>{" "}
        <input
          type="text"
          id="txtCourseImageUrl"
          className="form-control"
          {...register("CourseImageUrl")}
        />{" "}
        <button className="btn btn-success my-2">Add New Course</button>
      </form>
    </div>
  );
};
