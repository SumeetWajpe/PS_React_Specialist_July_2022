import { StyledButton } from "./styledcomponents/shared/Button";
import { Container } from "./styledcomponents/shared/Container";
import { StyledText } from "./styledcomponents/shared/StyledText";

export const Header = () => {
  return (
    <>
      <Container>
        <StyledText as="h1">Pubdemy</StyledText>
        <section>
          <StyledButton buttonType="secondary">Log in</StyledButton>
          <StyledButton>Sign up</StyledButton>
        </section>
      </Container>
    </>
  );
};
