import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export const Trainers: React.FC = () => {
  let [users, setUsers] = useState<any>([]); // use user model
  useEffect(() => {
    fetch("https://api.github.com/users")
      .then(res => res.json())
      .then(users => setUsers(users));
  }, []);

  return (
    <>
      <h2>Meet Our Trainers</h2>

      <ul className="list-group">
        {users.map(
          (
            user: any, // use user model
          ) => (
            <li key={user.id} className="list-group-item">
              <Link to={"/trainers/" + user.login}>{user.login}</Link>
            </li>
          ),
        )}
      </ul>
    </>
  );
};
