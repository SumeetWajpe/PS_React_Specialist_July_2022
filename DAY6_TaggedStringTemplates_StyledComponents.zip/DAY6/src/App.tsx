import React from "react";

import ListOfCourses from "./components/listofcourses";
import { ListOfCoursesFC } from "./components/listofcourses.functional";

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { NewCourse } from "./components/newcourse.reacthookfor";
import { Trainers } from "./components/trainers";
import { TrainerDetail } from "./components/trainer.details";
import { Header } from "./components/header";

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Pubdemy
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Courses
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/newcourse">
                  New Course
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/trainers">
                  Meet Our Trainers
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/styled">
                  Styled Components
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<ListOfCoursesFC />}></Route>
        <Route path="/newcourse" element={<NewCourse />}></Route>
        <Route path="/trainers" element={<Trainers />}></Route>
        <Route path="/trainers/:login" element={<TrainerDetail />}></Route>
        <Route path="/styled" element={<Header />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
