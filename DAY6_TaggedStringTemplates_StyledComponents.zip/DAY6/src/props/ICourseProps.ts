import React from "react";
import { CourseModel } from "../model/course.model";

export interface ICourseProps {
  coursedetails: CourseModel;
  DeleteACourse: (theCourseId: number) => void;
}

export interface ICoursePropsFC {
  coursedetails: CourseModel;
  DeleteACourse: (theCourseId: number) => void;
  children?: React.ReactNode | undefined;
}
