import { AnyAction, applyMiddleware, createStore } from "redux";
import rootReducer from "../reducers/root.reducer";
import thunk, { ThunkAction, ThunkDispatch } from "redux-thunk";
import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";
import { CourseModel } from "../../model/course.model";
import { TrainerModel } from "../../model/trainer.model";

// createStore(reducer,[preloadedstate],[enhancer])
type InitialState = {
  courses: CourseModel[];
  trainers: TrainerModel[];
};
let initialState: InitialState = {
  courses: [
    {
      id: 1,
      title: "React",
      price: 5000,
      likes: 400,
      rating: 5,
      trainer: "Micheal Kim",
      imageUrl:
        "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    },
    {
      id: 2,
      title: "Redux",
      price: 4000,
      likes: 600,
      rating: 5,
      trainer: "Andrew Collan",
      imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
    },
    {
      id: 3,
      title: "Node",
      price: 6000,
      likes: 900,
      rating: 4,
      trainer: "Sumeet Wajpe",
      imageUrl:
        "https://i0.wp.com/css-tricks.com/wp-content/uploads/2022/01/node-js-logo.png?fit=1200%2C600&ssl=1",
    },
    {
      id: 4,
      title: "Angular",
      price: 5000,
      likes: 200,
      rating: 3,
      trainer: "John Carter",
      imageUrl:
        "https://fs.hubspotusercontent00.net/hubfs/6426302/Imported_Blog_Media/7fad34d867a32f732b37534ff013e916-3-2.jpg",
    },
    {
      id: 5,
      title: "Flutter",
      price: 7000,
      likes: 700,
      rating: 4,
      trainer: "M Johnas",
      imageUrl:
        "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
    },
  ],
  trainers: [],
};

export type AppDispatch = typeof store.dispatch;
export type ReduxState = ReturnType<typeof rootReducer>;
export type TypedDispatch = ThunkDispatch<ReduxState, any, AnyAction>;
export type TypedThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  ReduxState,
  unknown,
  AnyAction
>;

// hooks.ts
export const useTypedDispatch = () => useDispatch<TypedDispatch>();
export const useTypedSelector: TypedUseSelectorHook<ReduxState> = useSelector;

const store = createStore(rootReducer, initialState, applyMiddleware(thunk));

export default store;
