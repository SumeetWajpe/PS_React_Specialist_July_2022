import { TrainerModel } from "../../model/trainer.model";
import { FetchAllTrainersAction } from "../actions/actionTypes";

type Action = FetchAllTrainersAction;

export function trainers(state: TrainerModel[] = [], action: Action) {
  switch (action.type) {
    case "ADD_A_TRAINER":
      console.log("Inside Trainers reducer !");
      return state;

    case "FETCH_ALL_TRAINERS":
      return action.payload;

    default:
      return state;
  }
}
