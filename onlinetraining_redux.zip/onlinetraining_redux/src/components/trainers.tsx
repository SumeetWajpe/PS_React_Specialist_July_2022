import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { AnyAction } from "redux";
import {
  FetchAllTrainers,
  FetchAllTrainersAsync,
} from "../redux/actions/actions";
import { useTypedDispatch, useTypedSelector } from "../redux/store/store";

export const Trainers: React.FC = () => {
  const dispatch = useTypedDispatch();
  const trainers = useTypedSelector(store => store.trainers);
  // const dispatch = useDispatch();
  // const trainers = useSelector((store: any) => store.trainers);
  useEffect(() => {
    dispatch(FetchAllTrainersAsync());
  }, []);

  return (
    <>
      <h2>Meet Our Trainers</h2>

      <ul className="list-group">
        {trainers.map(
          (
            user: any, // use user model
          ) => (
            <li key={user.id} className="list-group-item">
              {/* <Link to={"/trainers/" + user.login}>{user.login}</Link> */}
              {user.login}
            </li>
          ),
        )}
      </ul>
    </>
  );
};
