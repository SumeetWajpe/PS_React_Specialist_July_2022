import { useSelector } from "react-redux";
import { CourseModel } from "../model/course.model";
import { IListOfCoursesProps } from "../props/IListOfCoursesProps";
import { CourseFC } from "./course.functional";

export const ListOfCoursesFC: React.FC = () => {
  const courses = useSelector((store: any) => store.courses);

  let coursesToBeCreated = courses.map((course: CourseModel) => (
    <CourseFC coursedetails={course} key={course.id} />
  ));
  return (
    <>
      <h1>List Of Courses</h1>

      <div className="row">{coursesToBeCreated}</div>
    </>
  );
};
