import { CourseModel } from "../model/course.model";

export interface IListOfCoursesState {
  courses: CourseModel[];
}
