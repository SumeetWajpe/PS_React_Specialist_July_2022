export function trainers(state: any = [], action: any) {
  switch (action.type) {
    case "ADD_A_TRAINER":
      console.log("Inside Trainers reducer !");
      return state;

    case "FETCH_ALL_TRAINERS":
      return action.payload;

    default:
      return state;
  }
}
