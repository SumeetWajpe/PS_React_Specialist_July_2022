import { CourseModel } from "../../model/course.model";

export function courses(state: any = [], action: any) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      //console.log("Inside Courses reducer !");
      console.log(action);
      let index = state.findIndex(
        (course: CourseModel) => course.id === action.payload,
      );
      return [
        ...state.slice(0, index),
        {
          ...state[index],
          likes: state[index].likes + 1,
        },
        ...state.slice(index + 1),
      ];

    default:
      return state;
  }
}
