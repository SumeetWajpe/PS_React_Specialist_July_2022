import { combineReducers } from "redux";
import { courses } from "./courses.reducer";
import { trainers } from "./trainers.reducer";

const rootReducer = combineReducers({ courses, trainers });

export default rootReducer;
