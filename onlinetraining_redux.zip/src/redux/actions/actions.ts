import { AnyAction } from "redux";
import { ThunkAction } from "redux-thunk";
import store from "../store/store";

const INCREMENT_LIKES = "INCREMENT_LIKES";
// Action Creators
export function IncrementLikes(payload: number) {
  return { type: INCREMENT_LIKES, payload }; // Action
}

export function FetchAllTrainers(payload: any) {
  return { type: "FETCH_ALL_TRAINERS", payload };
}

export function FetchAllTrainersAsync() {
  return (dispatch: any) => {
    fetch("https://api.github.com/users")
      .then(res => res.json())
      .then(trainers => store.dispatch(FetchAllTrainers(trainers)));
  };
}

export function DeleteACourse() {
  return { type: "DELETE_A_COURSE" };
}

export function AddACourse() {
  return { type: "ADD_A_COURSE" };
}

export function AddATrainer() {
  return { type: "ADD_A_TRAINER" };
}

export function DeleteATrainer() {
  return { type: "DELETE_A_TRAINER" };
}
