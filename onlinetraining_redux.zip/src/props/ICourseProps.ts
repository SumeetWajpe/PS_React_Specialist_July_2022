import React from "react";
import { CourseModel } from "../model/course.model";

export interface ICourseProps {
  coursedetails: CourseModel;
}

export interface ICoursePropsFC {
  coursedetails: CourseModel;

  children?: React.ReactNode | undefined;
}
