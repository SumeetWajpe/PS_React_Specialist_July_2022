import { Add, Point } from "./math.js";

console.log("The addition is : " + Add(20, 30));
let point = new Point();
point.printPoint();
