export let Add = (x, y) => x + y;

export class Point {
  constructor(x = 100, y = 200) {
    this.x = x;
    this.y = y;
  }
  printPoint() {
    console.log(`[X=${this.x},Y=${this.y}]`);
  }
}
