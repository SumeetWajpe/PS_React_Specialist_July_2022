import App from "./App";
import Enzyme, { shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter() });

describe("test suite for counter", () => {
  it("counter is set to zero !", () => {
    let appInstance = shallow(<App />);
    let initialState = appInstance.state().count;
    expect(initialState).toBe(0);
  });

  it("increment the count on button click !", () => {
    let appInstance = shallow(<App />);
    let btn = appInstance.find("button");
    btn.simulate("click");
    let countText = appInstance.find("strong").text();
    expect(countText).toBe("1");
  });
});

// import { render, screen } from '@testing-library/react';
// import App from './App';

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });
