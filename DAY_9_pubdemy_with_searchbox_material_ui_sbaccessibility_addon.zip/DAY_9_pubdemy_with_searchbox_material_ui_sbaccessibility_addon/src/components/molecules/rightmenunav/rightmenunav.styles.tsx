import styled from "styled-components";
export const  Menu = styled.nav`
  display: none;
  position: absolute;
  width: 100%;
  top: 60px;
  left: 0px;
  padding: 8px;

  @media (min-width: 768px) {
    display: flex;
    background: none;
    left: initial;
    top: initial;
    margin: auto 0 auto auto;
    position: relative;
    width: initial;
    align-items: center;
  }
`;
