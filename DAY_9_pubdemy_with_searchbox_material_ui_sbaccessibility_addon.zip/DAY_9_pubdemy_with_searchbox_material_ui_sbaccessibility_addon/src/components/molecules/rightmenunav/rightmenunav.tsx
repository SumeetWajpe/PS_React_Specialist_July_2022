import React from "react";
import Button from "../../atoms/buttons/Button";
import Icon from "../../atoms/icons/icon";
import FlexWrapper from "../flexwrapper/flexwrapper";
import { Menu } from "./rightmenunav.styles";

type Props = {};

function RightMenuNav({}: Props) {
  return (
    <FlexWrapper>
      <Icon name="FaShoppingCart" size="1.5em" type="cart"></Icon>

      <Menu>
        <Button isPrimary={false}>Log In</Button>

        <Button>Sign Up</Button>
        <Button isPrimary={false}>
          <Icon name="BsGlobe"></Icon>
        </Button>
      </Menu>
    </FlexWrapper>
  );
}

export default RightMenuNav;
