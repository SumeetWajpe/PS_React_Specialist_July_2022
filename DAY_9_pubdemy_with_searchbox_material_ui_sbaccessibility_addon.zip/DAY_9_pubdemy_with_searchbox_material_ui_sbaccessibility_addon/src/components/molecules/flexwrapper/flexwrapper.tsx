import React, { ReactElement } from "react";
import StyledFlexWrapper from "./flexwrapper.styles";

type Props = {
  children: ReactElement[];
};

function FlexWrapper({ children }: Props) {
  return <StyledFlexWrapper>{children}</StyledFlexWrapper>;
}

export default FlexWrapper;
