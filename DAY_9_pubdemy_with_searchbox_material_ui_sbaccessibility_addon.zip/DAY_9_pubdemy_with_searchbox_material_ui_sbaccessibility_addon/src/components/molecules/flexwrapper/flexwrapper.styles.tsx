import React, { ReactElement } from "react";

import styled, { css } from "styled-components";

type WrapperProps = {
  type?: string;
  valign?: string;
  halign?: string;
};

const StyledFlexWrapper = styled.div<WrapperProps>`
  display: flex;
  align-items: ${props => props.valign};
  justify-content: ${props => props.halign};
`;

StyledFlexWrapper.defaultProps = {
  valign: "center",
};

export default StyledFlexWrapper;
