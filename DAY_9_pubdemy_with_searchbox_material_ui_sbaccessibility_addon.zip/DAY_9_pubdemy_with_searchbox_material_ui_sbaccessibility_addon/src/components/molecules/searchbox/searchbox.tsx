import React from "react";
import Icon from "../../atoms/icons/icon";
import SearchInput from "../../atoms/inputs/searchinput/searchinput";
import { StyledSearchBox } from "./searchbox.styles";

type SearchBoxProps = {};

function SearchBox({}: SearchBoxProps) {
  return (
    <StyledSearchBox>
      <Icon name="FaSearch"></Icon>

      <SearchInput placeholder="Search for anything" id="searchbox" />
    </StyledSearchBox>
  );
}

export default SearchBox;
