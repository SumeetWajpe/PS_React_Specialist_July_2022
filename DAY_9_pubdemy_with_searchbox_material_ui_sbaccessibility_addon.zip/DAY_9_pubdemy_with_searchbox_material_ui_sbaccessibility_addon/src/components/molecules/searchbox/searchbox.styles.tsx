import styled, { css } from "styled-components";

export const StyledSearchBox = styled.div`
  border: 1px solid black;
  border-radius: 30px;
  display: flex;

  width: 80%;
  align-items: center;
  background: rgb(246, 247, 249);
  padding: 5px;
  overflow: hidden;
  gap: 10px;
`;
