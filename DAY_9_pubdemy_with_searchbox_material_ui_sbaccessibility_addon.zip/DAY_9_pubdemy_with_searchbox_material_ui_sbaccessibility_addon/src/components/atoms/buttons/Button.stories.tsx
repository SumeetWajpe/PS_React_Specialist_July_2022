import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Button from "./Button";
import Icon from "../icons/icon";

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: "Pubdemy/Button",
  component: Button,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: "color" },
  },
} as ComponentMeta<typeof Button>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args

// export const PrimaryButton = () => <Button isPrimary={true}>Sign Up</Button>;
// export const SecondaryButton = () => <Button isPrimary={false}>Log In</Button>;

const Template: ComponentStory<typeof Button> = args => (
  <Button {...args}></Button>
);

export const PrimaryButton = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
PrimaryButton.args = {
  isPrimary: true,
  children: "Sign Up",
};

export const SecondaryButton = Template.bind({});
SecondaryButton.args = {
  isPrimary: false,
  children: "Log In",
};

export const ButtonWithIcon = Template.bind({});
ButtonWithIcon.args = {
  ...SecondaryButton.args,
  children: <Icon name="BsGlobe"></Icon>,
  label: "Choose Language",
};

// export const Large = Template.bind({});
// Large.args = {
//   size: 'large',
//   label: 'Button',
// };

// export const Small = Template.bind({});
// Small.args = {
//   size: 'small',
//   label: 'Button',
// };
