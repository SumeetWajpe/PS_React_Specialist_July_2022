import styled, { css } from "styled-components";

type StyledButtonProps = {
  buttonType?: "primary" | "secondary";
};

export const StyledButton = styled.button<StyledButtonProps>`
  background-color: rgb(0, 0, 0);
  color: white;
  padding: 0.5em 1em;
  border: 1px solid black;
  font-size: 1em;
  margin: 0.2em;
  white-space: nowrap;

  ${props =>
    props.buttonType === "secondary" &&
    css`
      background-color: white;
      color: black;

      &:hover {
        background-color: #e9e8e8;
      }
    `}
`;
