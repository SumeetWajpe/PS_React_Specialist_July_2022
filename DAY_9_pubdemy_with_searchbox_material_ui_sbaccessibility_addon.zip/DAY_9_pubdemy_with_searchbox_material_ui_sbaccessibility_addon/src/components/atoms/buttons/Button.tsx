import React, { ReactElement } from "react";
import { StyledButton } from "./Button.styles";

type Props = {
  isPrimary: boolean;
  children: ReactElement | string;
  label?: string;
};

function Button({ children, isPrimary, label }: Props) {
  return (
    <StyledButton
      buttonType={isPrimary ? "primary" : "secondary"}
      aria-label={label}
    >
      {children}
    </StyledButton>
  );
}

Button.defaultProps = {
  isPrimary: true,
};

export default Button;
