import React from "react";

type StyledTextProps = {};

function StyledText({}: StyledTextProps) {
  return <div>StyledText</div>;
}

export default StyledText;
