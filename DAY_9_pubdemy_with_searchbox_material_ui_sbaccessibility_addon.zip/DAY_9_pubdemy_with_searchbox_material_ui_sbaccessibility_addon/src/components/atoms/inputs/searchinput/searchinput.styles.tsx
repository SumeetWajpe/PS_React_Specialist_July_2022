import styled from "styled-components";

export const StyledSearchInput = styled.input`
  width: 85%;
  padding: 0 16px;
  background: rgb(246, 247, 249);
  line-height: 1.4em;
  padding: 5px;
  border: 0;
  color: black;
  outline: none;
`;
