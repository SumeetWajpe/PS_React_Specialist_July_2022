import React from "react";
import { StyledSearchInput } from "./searchinput.styles";

type SearchInputProps = {
  placeholder?: string;
  id: string;
};

function SearchInput({ ...props }: SearchInputProps) {
  return <StyledSearchInput {...props}></StyledSearchInput>;
}

export default SearchInput;
