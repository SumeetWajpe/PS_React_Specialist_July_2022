import React from "react";
import StyledIcon from "./icon.styles";
import { FaBars, FaBeer, FaSearch } from "react-icons/fa";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { BsGlobe } from "react-icons/bs";

type IconProps = {
  type?: string;
  name: string;
  size?: string;
};

function Icon({ type, name, size }: IconProps) {
  switch (name) {
    case "FaBars":
      return (
        <StyledIcon type="menu">
          <FaBars />
        </StyledIcon>
      );

    case "FaShoppingCart":
      return (
        <StyledIcon>
          <AiOutlineShoppingCart size={size} />
        </StyledIcon>
      );
    case "BsGlobe":
      return (
        <StyledIcon>
          <BsGlobe />
        </StyledIcon>
      );
    case "FaSearch":
      return (
        <StyledIcon>
          <FaSearch size={size} color="grey" />
        </StyledIcon>
      );
    default:
      return (
        <StyledIcon>
          <FaBeer />
        </StyledIcon>
      );
  }
}

export default Icon;
