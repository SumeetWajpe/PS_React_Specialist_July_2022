import React, { ReactElement } from "react";

import styled, { css } from "styled-components";

type IconProps = {
  type?: string;
};

const StyledIcon = styled.span<IconProps>`
padding: 5px;
  ${props =>
    props.type === "menu" &&
    css`
      @media (min-width: 768px) {
        display: none;
      }
    `}

  ${props =>
    props.type === "cart" &&
    css`
      margin-right: 20px;
    `}
`;

export default StyledIcon;
