import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";

import Icon from "../icons/icon";

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
  title: "Pubdemy/Icons",
  component: Icon,
  // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
  argTypes: {
    backgroundColor: { control: "color" },
  },
} as ComponentMeta<typeof Icon>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args

//export const MenuIcon = () => <Icon type="menu" name="FaBars"></Icon>;

const Template: ComponentStory<typeof Icon> = args => <Icon {...args}></Icon>;

export const MenuIcon = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
MenuIcon.args = {
  type: "menu",
  name: "FaBars",
};

// export const Secondary = Template.bind({});
// Secondary.args = {
//   label: 'Button',
// };

// export const Large = Template.bind({});
// Large.args = {
//   size: 'large',
//   label: 'Button',
// };

// export const Small = Template.bind({});
// Small.args = {
//   size: 'small',
//   label: 'Button',
// };
