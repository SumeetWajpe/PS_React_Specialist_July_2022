import CardThumbail from "../common/cards/cardthumbnails/cardthumbnails";
import { PageLayout } from "../common/PageLayout";

export const Home: React.FC = () => {
  return (
    <>
      <PageLayout>
        <h2>Students are viewing</h2>
        <CardThumbail></CardThumbail>
      </PageLayout>
    </>
  );
};
