import styled from "styled-components";
import StyledFlexWrapper from "../../molecules/flexwrapper/flexwrapper.styles";

export const StyledHeader = styled(StyledFlexWrapper).attrs({ as: "header" })`
  width: 100%;
  display: flex;
  padding: 0 16px;
  position: fixed;
  top: 0px;
  left: 0px;
  box-shadow: 0px 1px 10px grey;
  min-height: 60px;
  justify-content: space-between;
  gap: 10px;
`;
