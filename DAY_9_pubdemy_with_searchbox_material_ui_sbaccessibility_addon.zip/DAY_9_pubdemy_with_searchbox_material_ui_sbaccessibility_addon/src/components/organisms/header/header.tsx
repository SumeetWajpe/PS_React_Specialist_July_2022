import React from "react";
import Icon from "../../atoms/icons/icon";
import { StyledText } from "../../common/StyledText";

import RightMenuNav from "../../molecules/rightmenunav/rightmenunav";
import SearchBox from "../../molecules/searchbox/searchbox";
import { StyledHeader } from "./header.styles";

type HeaderProps = {};

function Header({}: HeaderProps) {
  return (
    <StyledHeader valign="center" halign="space-evenly">
      <Icon type="menu" name="FaBars"></Icon>

      <StyledText as="h1">Pubdemy</StyledText>

      <SearchBox></SearchBox>

      <RightMenuNav></RightMenuNav>
    </StyledHeader>
  );
}

export default Header;
