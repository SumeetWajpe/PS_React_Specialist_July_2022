import styled, { css } from "styled-components";

export const StyledText = styled.p``;
