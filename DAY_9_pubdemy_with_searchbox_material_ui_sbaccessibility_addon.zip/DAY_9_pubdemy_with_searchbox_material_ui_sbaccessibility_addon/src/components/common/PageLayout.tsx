import styled from "styled-components";
import Header from "../organisms/header/header";

interface Props {
  children: React.ReactNode;
}

const Content = styled.main`
  max-width: 800px;
  margin: 80px 80px 0 auto;
  padding: 0px 16px;
`;

export const PageLayout: React.FC<Props> = ({ children }) => {
  return (
    <>
      <Header></Header>
      <Content>{children}</Content>
    </>
  );
};
