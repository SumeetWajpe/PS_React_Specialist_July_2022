import React from "react";
import { createGlobalStyle } from "styled-components";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import { Home } from "./components/pages/Home";
import { LogIn } from "./components/pages/Login";

const GlobalStyle = createGlobalStyle`

*{
  margin: 0px;
  padding: 0px;
  box-sizing:border-box;
}

body{
  background: white;
  min-height: 100vh;
}

`;

function App() {
  return (
    <>
      <GlobalStyle />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/login" element={<LogIn />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
