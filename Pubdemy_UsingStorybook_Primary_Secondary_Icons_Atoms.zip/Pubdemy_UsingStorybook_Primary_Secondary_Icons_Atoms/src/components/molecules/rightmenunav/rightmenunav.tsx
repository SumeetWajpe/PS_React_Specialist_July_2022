import React from "react";
import Button from "../../atoms/buttons/button";
import Icon from "../../atoms/icons/icon";

import { Menu } from "./rightmenunav.styles";

type Props = {};

function RightNavMenu({}: Props) {
  return (
    <Menu>
      <Icon name="BiCart" size="2em"></Icon>
      <Button primary={false}>Login</Button>
      <Button primary={true}> Sign Up</Button>
      <Button primary={false}>
        <Icon name="BsGlobe"></Icon>
      </Button>
    </Menu>
  );
}

export default RightNavMenu;
