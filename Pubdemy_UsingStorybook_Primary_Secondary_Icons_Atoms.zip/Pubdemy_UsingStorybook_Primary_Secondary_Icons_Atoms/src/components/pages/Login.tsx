import { PageLayout } from "../common/PageLayout";

export const LogIn: React.FC = () => {
  return (
    <>
      <PageLayout>
        <h1>Login</h1>
      </PageLayout>
    </>
  );
};
