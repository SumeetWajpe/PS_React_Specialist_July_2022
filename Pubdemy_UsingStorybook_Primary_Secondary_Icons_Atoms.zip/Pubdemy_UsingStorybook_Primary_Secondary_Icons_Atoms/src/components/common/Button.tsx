import styled, { css } from "styled-components";

type StyledButtonProps = {
  buttonType?: "primary" | "secondary";
};

export const StyledButton = styled.button<StyledButtonProps>`
  background-color: rgb(0, 0, 0);
  color: white;
  padding: 0.5em 1em;
  border: none;
  font-size: 1.1em;
  margin: 0.2em;

  ${props =>
    props.buttonType === "secondary" &&
    css`
      background-color: white;
      color: black;
      border: 1px solid black;
      &:hover {
        background-color: #e9e8e8;
      }
    `}
`;
