import styled from "styled-components";
import RightNavMenu from "../molecules/rightmenunav/rightmenunav";
import { StyledButton } from "./Button";
import { StyledText } from "./StyledText";

const HeaderWrapper = styled.header`
  width: 100%;
  height: 60px;
  display: flex;
  justify-content: space-between;
  align-items: center;

  padding: 0 16px;
  position: fixed;
  top: 0px;
  left: 0px;
  align-items: center;
`;

const MenuIcon = styled.i`
  font-size: 1.2em;

  @media (min-width: 768px) {
    display: none;
  }
`;

const Menu = styled.nav`
  display: none;
  position: absolute;
  width: 100%;
  top: 60px;
  left: 0px;
  padding: 8px;

  @media (min-width: 768px) {
    display: flex;
    background: none;
    left: initial;
    top: initial;
    margin: auto 0 auto auto;
    position: relative;
    width: initial;
  }
`;

export const Header: React.FC = () => {
  return (
    <HeaderWrapper>
      <MenuIcon className="fa-solid fa-bars"></MenuIcon>
      <StyledText as="h1">Pubdemy</StyledText>

      <RightNavMenu></RightNavMenu>
    </HeaderWrapper>
  );
};
