import React, { ReactElement } from "react";
import { StyledButton } from "./button.styles";

type ButtonProps = {
  primary: boolean;
  children: ReactElement | string;
};

function Button({ primary, children }: ButtonProps) {
  return (
    <StyledButton buttonType={primary ? "primary" : "secondary"}>
      {children}
    </StyledButton>
  );
}

Button.defaultProps = {
  primary: true,
};

export default Button;
