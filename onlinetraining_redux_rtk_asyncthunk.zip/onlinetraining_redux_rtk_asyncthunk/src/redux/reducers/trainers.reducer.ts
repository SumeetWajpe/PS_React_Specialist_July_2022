import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { TrainerModel } from "../../model/trainer.model";

export interface TrainersState {
  trainers: TrainerModel[];
  // loading: boolean;
}

const initialState: TrainersState = {
  trainers: [],
  // loading: true,
};

export const fetchTrainersAsync = createAsyncThunk<TrainerModel[]>(
  "trainers/fetchAllTrainers",
  async () => {
    const responseJSON = await fetch("https://api.github.com/users");
    const response: TrainerModel[] = await responseJSON.json();
    // The value we return becomes the `fulfilled` action payload
    return response;
  },
);

export const trainersSlice = createSlice({
  name: "trainers",
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder.addCase(fetchTrainersAsync.fulfilled, (state, { payload }) => {
      state.trainers.push(...payload);
      // state.loading = false;
    });
  },
});

export default trainersSlice.reducer;
