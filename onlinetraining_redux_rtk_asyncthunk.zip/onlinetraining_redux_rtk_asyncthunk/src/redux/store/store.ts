import { configureStore } from "@reduxjs/toolkit";
import coursesReducer from "../reducers/courses.reducer";
import trainersReducer from "../reducers/trainers.reducer";

const store = configureStore({
  reducer: {
    courses: coursesReducer,
    trainers: trainersReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
// typedAppDispatch
export default store;
