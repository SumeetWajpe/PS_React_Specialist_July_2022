import { CourseModel } from "../model/course.model";

export interface IListOfCoursesProps {
  courses?: CourseModel[];
}
