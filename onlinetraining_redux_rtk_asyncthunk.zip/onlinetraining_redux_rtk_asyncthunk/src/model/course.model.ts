export class CourseModel {
  constructor(
    public id: number,
    public likes: number,
    public title: string,
    public price: number,
    public rating: number,
    public trainer: string,
    public imageUrl: string,
  ) {}
}
