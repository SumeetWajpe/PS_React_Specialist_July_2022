function AboutDetails() {
  return <h2>About Details !</h2>;
}
export default AboutDetails;
