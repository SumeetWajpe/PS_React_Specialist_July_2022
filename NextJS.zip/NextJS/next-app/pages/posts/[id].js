import React from "react";
import { useRouter } from "next/router";

function PostsDetails({ postdetails }) {
  return (
    <div>
      <h2>{postdetails.title}</h2>
      <div>{postdetails.body}</div>
    </div>
  );
}

export async function getServerSideProps(context) {
  const { params } = context;
  const { id } = params;
  // context.req.headers.cookie - auth token
  const resp = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`);
  const postdetails = await resp.json();
  return {
    props: {
      postdetails,
    }, // will be passed to the page component as props
  };
}
export default PostsDetails;
