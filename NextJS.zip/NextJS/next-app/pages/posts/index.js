import Head from "next/head";
import Link from "next/link";
function Posts({ posts }) {
  return (
    <>
      <Head>
        <title>This is an about page !</title>
      </Head>
      <h2>Posts List !</h2>
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <Link href={`http://localhost:3000/posts/${post.id}`}>
              {post.title}
            </Link>{" "}
          </li>
        ))}
      </ul>
    </>
  );
}

export async function getServerSideProps(context) {
  // context.req.headers.cookie - auth token
  const resp = await fetch("https://jsonplaceholder.typicode.com/posts");
  const posts = await resp.json();
  return {
    props: {
      posts,
    }, // will be passed to the page component as props
  };
}

export default Posts;
