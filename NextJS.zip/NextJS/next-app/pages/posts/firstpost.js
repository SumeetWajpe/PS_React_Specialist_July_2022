import React from "react";

function Firstpost() {
  return <div>First Post</div>;
}

export default Firstpost;
